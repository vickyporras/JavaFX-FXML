package com.foc.u02_cur2324;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class Almacenamiento extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_almacenamiento);

        //Escritura en Almacenamiento Interno
        //Crear un flujo de escritura
        try {
            OutputStreamWriter fout = new OutputStreamWriter(openFileOutput("fichero_interno.txt", Context.MODE_PRIVATE));
            fout.write("Prueba de escritura en almacenamiento interno");
            //Cerramos el flujo
            fout.close();
            String t = getFileStreamPath("fichero_interno.txt").toString();
            Toast.makeText(this, "Se ha escrito en el almacenamiento interno: " + t, Toast.LENGTH_LONG).show();
        } catch (Exception ex) {
            Toast.makeText(this, "No se ha escrito en el almacenamiento interno: ", Toast.LENGTH_LONG).show();
        }

        //Lectura del almacenamiento interno
        //Creo un flujo de lectura
        try {
            BufferedReader fin = new BufferedReader(new InputStreamReader(openFileInput("fichero_interno.txt")));
            String texto = fin.readLine();
            fin.close();
            Toast.makeText(this, "Se ha leído en el almacenamiento interno: " + texto, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se ha leído en el almacenamiento interno: ", Toast.LENGTH_LONG).show();
        }

        //Lectura del almacenamiento interno como recurso de la app
        try{
            InputStream fraw = getResources().openRawResource(R.raw.fichero_recursos);
            BufferedReader brin = new BufferedReader(new InputStreamReader(fraw));
            String texto = brin.readLine();
            Toast.makeText(this, "Se ha leído del almacenamiento interno de los recursos: "+texto, Toast.LENGTH_LONG).show();
            fraw.close();
            brin.close();
        } catch (Exception e) {
            Toast.makeText(this, "No se ha leído del almacenamiento interno de los recursos", Toast.LENGTH_LONG).show();
        }

        //Comprobar disponibilidad de almacenamiento externo
        boolean sdDisponible = false;
        boolean sdAccesoEscritura = false;
        String estado = Environment.getExternalStorageState();
        if(estado.equals(Environment.MEDIA_MOUNTED)){
            sdDisponible = true;
            sdAccesoEscritura = true;
        }
        else if (estado.equals(Environment.MEDIA_MOUNTED_READ_ONLY)){
            sdDisponible = true;
        }
        Toast.makeText(this, "Disponible:" + sdDisponible + " Escritura:" + sdAccesoEscritura, Toast.LENGTH_LONG).show();

        //Escribir en el almacenamiento externo comprobando previamente si está disponible
        if(sdDisponible && sdAccesoEscritura){
            try {
                File ruta_sd = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
                File f = new File(ruta_sd.getAbsolutePath().toString(), "externo.txt");
                OutputStreamWriter fout = new OutputStreamWriter(new FileOutputStream(f));
                fout.write("Prueba de escritura en almacenamiento externo");
                Toast.makeText(this, "Se ha escrito en almacenamiento externo",
                        Toast.LENGTH_SHORT).show();
                fout.close();
            }
            catch (java.io.IOException e){
                e.printStackTrace();
                Toast.makeText(this, "No se ha escrito en almacenamiento externo",
                        Toast.LENGTH_SHORT).show();            }
        }

    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.btGuardar){
            SharedPreferences sharePref = getPreferences(Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sharePref.edit();

            EditText etConfNombre = findViewById(R.id.etConfNombre);
            CheckBox cbConfCond = findViewById(R.id.cbConfCond);

            edit.putString("Nombre",etConfNombre.getText().toString());
            edit.putBoolean("Condiciones",cbConfCond.isChecked());
            if (edit.commit()){
                Toast.makeText(this,"Se ha almacenado la configuración", Toast.LENGTH_LONG).show();
            }
            else {
                Toast.makeText(this,"No se ha almacenado la configuración", Toast.LENGTH_LONG).show();
            }
        }
    }
}