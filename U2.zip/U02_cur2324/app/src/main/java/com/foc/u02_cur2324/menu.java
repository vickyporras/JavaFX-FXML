package com.foc.u02_cur2324;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;

public class menu extends AppCompatActivity implements View.OnClickListener, View.OnKeyListener,
    View.OnTouchListener{

    TextView tvRes;
    Button btForm, btBD, btAlmacen;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        //Recupero el textview de la interfaz
        tvRes = findViewById(R.id.tvRes);
        //Hacerlo no visible
        tvRes.setVisibility(View.INVISIBLE);

        //Recupero los botones e imagen de la interfaz
        btForm = findViewById(R.id.btForm);
        btBD = findViewById(R.id.btBD);
        btAlmacen = findViewById(R.id.btAlmacen);
        imageView = findViewById(R.id.fondoFoc);

        //Asignación de los listeners de teclado
        btForm.setOnKeyListener(this);
        btBD.setOnKeyListener(this);

        //Asignamos el listener al toque de imagen
        imageView.setOnTouchListener(this);

    }

    @Override
    public void onClick(View v) {

        //Han hecho click en el botón Formulario
        if (v.getId()==R.id.btForm){
            //Voy a la ventana (pantalla o intent) de la actividad principal
            //Crear un intent
            Intent intent = new Intent(this, MainActivity.class);
            //Iniciar la actividad que hay en el intent
            startActivity(intent);
        }
        else if (v.getId()==R.id.btBD){
            //Capturo el botón que se pulsado
            Button btPulsado = (Button) v;
            //Asigno el texto al botón del TextView
            tvRes.setText(btPulsado.getText());
            tvRes.setVisibility(View.VISIBLE);
        }
        else if (v.getId()==R.id.btAlmacen){
            //Voy a la ventana (pantalla o intent) de la actividad principal
            //Crear un intent
            Intent intent = new Intent(this, Almacenamiento.class);
            //Iniciar la actividad que hay en el intent
            startActivity(intent);
        }
    }

    @Override
    public boolean onKey(View v, int keyCode, KeyEvent event) {
        //Si hemos manejado el evento devolvemos true si no false
        boolean hecho = false;

        //Control de la tecla que se ha pulsado
        switch (keyCode){
            case KeyEvent.KEYCODE_F:
            case KeyEvent.KEYCODE_1:
                //Voy a la ventana (pantalla o intent) de la actividad principal
                //Crear un intent
                Intent intent = new Intent(this, MainActivity.class);
                //Iniciar la actividad que hay en el intent
                startActivity(intent);
                hecho = true;
                break;
            case KeyEvent.KEYCODE_B:
            case KeyEvent.KEYCODE_2:
                //Cojo el texto del botón que se ha pulsado
                tvRes.setText(btBD.getText());
                tvRes.setVisibility(View.VISIBLE);
                hecho = true;
                break;
        }

        return hecho;
    }

    @Override
    public boolean onTouch(View v, MotionEvent motionEvent) {
        //Si hemos manejado el evento devolvemos true si no false
        boolean hecho = false;
        tvRes.setVisibility(View.VISIBLE);
        switch (motionEvent.getAction()){
            //pulsar la pantalla
            case MotionEvent.ACTION_DOWN:
                tvRes.setVisibility(View.VISIBLE);
                tvRes.setText("Pulsado en: X="+ motionEvent.getX() +" Y="+ motionEvent.getY());
                hecho = true;
                break;
            //levantar el dedo de la pantalla, dejo de pulsar
            case MotionEvent.ACTION_UP:
                tvRes.setVisibility(View.VISIBLE);
                tvRes.setText("Levantado en: X="+ motionEvent.getX() +" Y="+ motionEvent.getY());
                hecho = true;
                break;
            //arrastras por la pantalla
            case MotionEvent.ACTION_MOVE:
                tvRes.setVisibility(View.VISIBLE);
                tvRes.setText("Arrastrado por: X="+ motionEvent.getX() +" Y="+ motionEvent.getY());
                hecho = true;
                break;
        }

        return hecho;
    }
}