package com.foc.u02_cur2324;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //leer de las sharepreferences
        SharedPreferences sp = getSharedPreferences("Almacenamiento", Context.MODE_PRIVATE);
        String nombre = sp.getString("Nombre","");
        Boolean condiciones = sp.getBoolean("Condiciones",false);
        CheckBox checkBox = findViewById(R.id.checkBox);
        EditText etCuadroTexto = findViewById(R.id.etCuadroTexto);
        checkBox.setChecked(condiciones);
        etCuadroTexto.setText(nombre);
    }
}